/* Include extra includes needed by most/all pseudo-clients.
 *
 * (C) 2003-2014 Anope Team
 * Contact us at team@anope.org
 *
 * Please read COPYING and README for further details.
 *
 * Based on the original code of Epona by Lara.
 * Based on the original code of Services by Andy Church. 
 * 
 *
 */

#include "commands.h"
#include "language.h"
#include "timeout.h"
#include "encrypt.h"
#include "datafiles.h"
#include "slist.h"
