#ifndef CATSERV_MESSAGES_H
#define CATSERV_MESSAGES_H

#include "module.h"

CommandHash *Catserv_cmdTable[MAX_CMD_HASH];
void addMessageList(void);

#endif

