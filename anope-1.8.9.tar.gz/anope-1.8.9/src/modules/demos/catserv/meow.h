#ifndef CATSERV_MEOW_H
#define CATSERV_MEOW_H

#include "module.h"

int do_meow(User * u);

#endif

