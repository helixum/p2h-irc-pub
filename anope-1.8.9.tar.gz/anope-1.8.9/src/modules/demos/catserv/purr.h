#ifndef CATSERV_PURR_H
#define CATSERV_PURR_H

#include "module.h"

int do_purr(User * u);

#endif

